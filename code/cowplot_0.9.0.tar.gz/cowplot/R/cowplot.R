#' cowplot.
#'
#' @name cowplot
#' @docType package
#' @import ggplot2
NULL

